import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      crypto: "empty-module",
    },
  },
  assetsInclude: ['**/*.wasm'],
  server: {
    // Serve static assets, including .wasm files, from public directory
    static: {
      publicDir: 'public',
    },
  },
  define: {
    global: "globalThis",
  },
  optimizeDeps: {
    include: ["@xmtp/xmtp-js", "ethers"], // Include these in the dependency optimization process
  },
  build: {
    target: "esnext", // Set the build target for better modern syntax support
    rollupOptions: {
      output: {
        manualChunks: undefined, // Avoid splitting chunks unnecessarily
      },
    },
  },
});
