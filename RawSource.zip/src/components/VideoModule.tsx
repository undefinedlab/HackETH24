import Video from './Video/Video';
import VideoPlayer from './Video/Player';

export { Video, VideoPlayer };
